// ----------------------------------------------------------------------

export const varHover = (scale?: number) => ({
  hover: {
    scale: scale || 1.1,
  },
});
