export const StatusCodes = {
  NONE: 'NONE',
  REQUESTED: 'REQUESTED',
  ERROR: 'ERROR',
  COMPLETED: 'COMPLETED'
};
